In each folder, there's a cabinet animation. Files are separated into frames in PNG format, sprite sheet, and also GIF.

If you want two cabinets to open at the same time, use only the first 3 frames; use the fourth frame only if a single cabinet opens.

Also, be mindful that if you combine two cabinets, they will have a double border. To avoid this, overlap them by one pixel on the X-axis.

When combining cabinets, use the "Countertop" file. You can stretch it freely along the X-axis without losing quality. Use this to connect the countertops of the cabinets without it looking strange.